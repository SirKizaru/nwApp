import { useState } from "react";
import { Bell, Menu, Plus, User } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { PostForm } from "@/components/PostForm";
import { Post } from "@/types";
import { toast } from "sonner";

interface HeaderProps {
  onMenuClick: () => void;
}

export default function Header({ onMenuClick }: HeaderProps) {
  const [isNewPostOpen, setIsNewPostOpen] = useState(false);

  const mockPlatforms = [
    { id: "TikTok", name: "TikTok", color: "#FF004F" },
    { id: "Instagram Reels", name: "Instagram Reels", color: "#833AB4" },
    { id: "YouTube Shorts", name: "YouTube Shorts", color: "#FF0000" },
  ];

  const handleSavePost = (newPost: Post) => {
    // In a real app, this would save the post to a database
    // For now, we'll just show a success message
    toast.success("Post created successfully!");
  };

  return (
    <header className="sticky top-0 z-10 flex h-16 items-center gap-4 border-b bg-background px-6">
      <Button variant="ghost" size="icon" className="md:hidden" onClick={onMenuClick}>
        <Menu className="h-5 w-5" />
        <span className="sr-only">Toggle Menu</span>
      </Button>
      
      <div className="flex-1 md:grow-0 md:w-[200px] lg:w-[250px]">
        <Input 
          placeholder="Search posts..." 
          className="rounded-full bg-muted h-9" 
        />
      </div>
      
      <div className="flex-1" />
      
      <Button 
        variant="default" 
        size="sm" 
        className="gap-2"
        onClick={() => setIsNewPostOpen(true)}
      >
        <Plus className="h-4 w-4" />
        <span className="hidden sm:inline">New Post</span>
      </Button>
      
      <DropdownMenu>
        <DropdownMenuTrigger asChild>
          <Button variant="ghost" size="icon" className="relative">
            <Bell className="h-5 w-5" />
            <span className="absolute -top-1 -right-1 flex h-4 w-4 items-center justify-center rounded-full bg-primary text-[10px] text-primary-foreground">
              3
            </span>
            <span className="sr-only">Notifications</span>
          </Button>
        </DropdownMenuTrigger>
        <DropdownMenuContent align="end" className="w-80">
          <DropdownMenuLabel>Notifications</DropdownMenuLabel>
          <DropdownMenuSeparator />
          <div className="max-h-96 overflow-y-auto">
            {['Video successfully published to TikTok', 'Scheduled post is ready to publish', 'YouTube Shorts post failed to upload'].map((notification, index) => (
              <DropdownMenuItem key={index} className="cursor-pointer p-4">
                <span>{notification}</span>
              </DropdownMenuItem>
            ))}
          </div>
        </DropdownMenuContent>
      </DropdownMenu>
      
      <DropdownMenu>
        <DropdownMenuTrigger asChild>
          <Button variant="ghost" size="icon" className="rounded-full">
            <Avatar className="h-8 w-8">
              <AvatarFallback className="bg-primary text-primary-foreground">
                <User className="h-4 w-4" />
              </AvatarFallback>
            </Avatar>
            <span className="sr-only">User menu</span>
          </Button>
        </DropdownMenuTrigger>
        <DropdownMenuContent align="end">
          <DropdownMenuLabel>My Account</DropdownMenuLabel>
          <DropdownMenuSeparator />
          <DropdownMenuItem>Profile</DropdownMenuItem>
          <DropdownMenuItem>Connected Accounts</DropdownMenuItem>
          <DropdownMenuSeparator />
          <DropdownMenuItem>Log out</DropdownMenuItem>
        </DropdownMenuContent>
      </DropdownMenu>

      {/* New Post Modal */}
      <PostForm
        isOpen={isNewPostOpen}
        onClose={() => setIsNewPostOpen(false)}
        platforms={mockPlatforms}
        onSave={handleSavePost}
      />
    </header>
  );
}