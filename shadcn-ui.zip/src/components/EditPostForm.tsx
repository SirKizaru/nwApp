import { useState } from "react";
import { 
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Calendar as CalendarIcon, UploadCloud, X } from "lucide-react";
import { Calendar } from "@/components/ui/calendar";
import { format } from "date-fns";
import { cn } from "@/lib/utils";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import { Badge } from "@/components/ui/badge";
import { Checkbox } from "@/components/ui/checkbox";
import { Post } from "@/types";
import { toast } from "sonner";

interface EditPostFormProps {
  isOpen: boolean;
  onClose: () => void;
  post?: Post;
  onSave: (post: Post) => void;
}

export function EditPostForm({ 
  isOpen, 
  onClose, 
  post, 
  onSave 
}: EditPostFormProps) {
  const isEditing = !!post;
  const defaultTags = post?.tags?.join(", ") || "";
  const platforms = ["TikTok", "Instagram Reels", "YouTube Shorts"];
  
  const [title, setTitle] = useState(post?.title || "");
  const [description, setDescription] = useState(post?.description || "");
  const [file, setFile] = useState<File | null>(null);
  const [thumbnailFile, setThumbnailFile] = useState<File | null>(null);
  const [scheduledDate, setScheduledDate] = useState<Date | undefined>(
    post?.scheduledDate ? new Date(post.scheduledDate) : undefined
  );
  const [selectedPlatforms, setSelectedPlatforms] = useState<string[]>(
    post?.platforms || []
  );
  const [tags, setTags] = useState(defaultTags);
  const [status, setStatus] = useState<"draft" | "scheduled" | "published">(
    post?.status || "draft"
  );

  const handleSubmit = () => {
    if (!title.trim()) {
      toast.error("Title is required");
      return;
    }
    
    if (selectedPlatforms.length === 0) {
      toast.error("Select at least one platform");
      return;
    }

    if (status === "scheduled" && !scheduledDate) {
      toast.error("Schedule date is required");
      return;
    }

    const updatedPost: Post = {
      id: post?.id || Math.random().toString(36).substring(2, 11),
      title,
      description,
      videoFile: post?.videoFile || "",
      thumbnail: post?.thumbnail || null,
      scheduledDate: scheduledDate ? scheduledDate.toISOString() : null,
      publishedDate: post?.publishedDate || null,
      status,
      platforms: selectedPlatforms,
      tags: tags.split(",").map(tag => tag.trim()).filter(tag => tag.length > 0),
    };

    onSave(updatedPost);
    toast.success(`Post ${isEditing ? "updated" : "created"} successfully`);
    onClose();
  };

  const handlePlatformToggle = (platform: string) => {
    setSelectedPlatforms(prev => 
      prev.includes(platform)
        ? prev.filter(p => p !== platform)
        : [...prev, platform]
    );
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-[600px] max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>{isEditing ? "Edit Post" : "Create New Post"}</DialogTitle>
          <DialogDescription>
            {isEditing 
              ? "Update your post details and schedule" 
              : "Fill in the details to create a new post"}
          </DialogDescription>
        </DialogHeader>

        <div className="grid gap-4 py-4">
          <div className="space-y-2">
            <Label htmlFor="title">Title</Label>
            <Input
              id="title"
              placeholder="Enter post title"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
            />
          </div>
          
          <div className="space-y-2">
            <Label htmlFor="description">Description</Label>
            <Textarea
              id="description"
              placeholder="Enter post description"
              className="min-h-[100px]"
              value={description}
              onChange={(e) => setDescription(e.target.value)}
            />
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label>Video File</Label>
              <div className="border border-dashed rounded-md p-4">
                {post?.videoFile ? (
                  <div className="flex items-center justify-between bg-muted/50 p-2 rounded">
                    <span className="text-sm truncate">
                      {post.videoFile}
                    </span>
                  </div>
                ) : (
                  <label className="flex flex-col items-center gap-2 cursor-pointer">
                    <UploadCloud className="h-8 w-8 text-muted-foreground" />
                    <span className="text-sm text-muted-foreground">
                      Click to upload video
                    </span>
                    <Input 
                      type="file" 
                      className="hidden" 
                      accept="video/*"
                      onChange={(e) => {
                        const selectedFile = e.target.files?.[0];
                        if (selectedFile) {
                          setFile(selectedFile);
                        }
                      }} 
                    />
                  </label>
                )}
              </div>
            </div>
            
            <div className="space-y-2">
              <Label>Thumbnail Image</Label>
              <div className="border border-dashed rounded-md p-4">
                {post?.thumbnail ? (
                  <div className="flex items-center justify-between bg-muted/50 p-2 rounded">
                    <span className="text-sm truncate">
                      {post.thumbnail}
                    </span>
                  </div>
                ) : (
                  <label className="flex flex-col items-center gap-2 cursor-pointer">
                    <UploadCloud className="h-8 w-8 text-muted-foreground" />
                    <span className="text-sm text-muted-foreground">
                      Click to upload thumbnail
                    </span>
                    <Input 
                      type="file" 
                      className="hidden" 
                      accept="image/*"
                      onChange={(e) => {
                        const selectedFile = e.target.files?.[0];
                        if (selectedFile) {
                          setThumbnailFile(selectedFile);
                        }
                      }} 
                    />
                  </label>
                )}
              </div>
            </div>
          </div>

          <div className="space-y-2">
            <Label>Schedule Date</Label>
            <Popover>
              <PopoverTrigger asChild>
                <Button
                  variant="outline"
                  className={cn(
                    "w-full justify-start text-left font-normal",
                    !scheduledDate && "text-muted-foreground"
                  )}
                >
                  <CalendarIcon className="mr-2 h-4 w-4" />
                  {scheduledDate ? format(scheduledDate, "PPP") : "Select date"}
                </Button>
              </PopoverTrigger>
              <PopoverContent className="w-auto p-0">
                <Calendar
                  mode="single"
                  selected={scheduledDate}
                  onSelect={setScheduledDate}
                  initialFocus
                  disabled={(date) => date < new Date()}
                />
              </PopoverContent>
            </Popover>
          </div>

          <div className="space-y-2">
            <Label>Status</Label>
            <div className="flex items-center space-x-4">
              <div className="flex items-center space-x-2">
                <input
                  type="radio"
                  id="draft"
                  checked={status === "draft"}
                  onChange={() => setStatus("draft")}
                  className="accent-primary"
                />
                <label htmlFor="draft">Draft</label>
              </div>
              <div className="flex items-center space-x-2">
                <input
                  type="radio"
                  id="scheduled"
                  checked={status === "scheduled"}
                  onChange={() => setStatus("scheduled")}
                  className="accent-primary"
                />
                <label htmlFor="scheduled">Schedule for later</label>
              </div>
              {post?.status === "published" && (
                <div className="flex items-center space-x-2">
                  <input
                    type="radio"
                    id="published"
                    checked={status === "published"}
                    onChange={() => setStatus("published")}
                    className="accent-primary"
                  />
                  <label htmlFor="published">Published</label>
                </div>
              )}
            </div>
          </div>

          <div className="space-y-2">
            <Label>Platforms</Label>
            <div className="flex flex-wrap gap-3">
              {platforms.map((platform) => (
                <div 
                  key={platform} 
                  className={cn(
                    "flex items-center border rounded-lg p-3 cursor-pointer transition-colors",
                    selectedPlatforms.includes(platform) 
                      ? "border-primary/50 bg-primary/10"
                      : "border-border"
                  )}
                  onClick={() => handlePlatformToggle(platform)}
                >
                  <span className="ml-2">{platform}</span>
                  <Checkbox 
                    checked={selectedPlatforms.includes(platform)}
                    className="ml-2"
                    onCheckedChange={() => handlePlatformToggle(platform)}
                  />
                </div>
              ))}
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="tags">Tags</Label>
            <Input
              id="tags"
              placeholder="Enter tags separated by commas"
              value={tags}
              onChange={(e) => setTags(e.target.value)}
            />
            {tags && (
              <div className="flex flex-wrap gap-2 mt-2">
                {tags.split(",")
                  .map(tag => tag.trim())
                  .filter(tag => tag.length > 0)
                  .map((tag, index) => (
                    <Badge key={index} variant="secondary">{tag}</Badge>
                  ))
                }
              </div>
            )}
          </div>
        </div>
        
        <DialogFooter>
          <Button variant="outline" onClick={onClose}>Cancel</Button>
          <Button onClick={handleSubmit}>{isEditing ? "Update" : "Create"} Post</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}