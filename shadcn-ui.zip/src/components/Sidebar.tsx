import { Link, useLocation } from "react-router-dom";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Sheet, SheetContent } from "@/components/ui/sheet";
import {
  Calendar,
  LayoutDashboard,
  Settings,
  FileVideo,
  Share2,
  BarChart3,
  X
} from "lucide-react";

interface SidebarProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  isMobile: boolean;
}

const items = [
  {
    name: "Dashboard",
    path: "/",
    icon: LayoutDashboard,
  },
  {
    name: "Calendar",
    path: "/calendar",
    icon: Calendar,
  },
  {
    name: "Posts",
    path: "/posts",
    icon: FileVideo,
  },
  {
    name: "Platforms",
    path: "/platforms",
    icon: Share2,
  },
  {
    name: "Analytics",
    path: "/analytics",
    icon: BarChart3,
  },
  {
    name: "Settings",
    path: "/settings",
    icon: Settings,
  },
];

export default function Sidebar({ open, onOpenChange, isMobile }: SidebarProps) {
  const location = useLocation();
  
  const content = (
    <div className="h-full flex flex-col">
      <div className="flex h-16 items-center border-b px-4">
        <Link
          to="/"
          className="flex items-center gap-2 font-semibold"
          onClick={() => isMobile && onOpenChange(false)}
        >
          <FileVideo className="h-6 w-6 text-primary" />
          <span className="text-xl font-bold">VideoPost</span>
        </Link>
        {isMobile && (
          <Button
            variant="ghost"
            size="icon"
            className="absolute right-4 top-4"
            onClick={() => onOpenChange(false)}
          >
            <X className="h-4 w-4" />
            <span className="sr-only">Close</span>
          </Button>
        )}
      </div>
      <ScrollArea className="flex-1 px-2">
        <nav className="grid items-start gap-2 py-4">
          {items.map((item) => (
            <Link
              key={item.path}
              to={item.path}
              onClick={() => isMobile && onOpenChange(false)}
              className={cn(
                "group flex items-center gap-3 rounded-md px-3 py-2 text-sm font-medium hover:bg-accent hover:text-accent-foreground",
                location.pathname === item.path || 
                (item.path === "/" && location.pathname === "/") 
                  ? "bg-accent text-accent-foreground"
                  : "transparent"
              )}
            >
              <item.icon className="h-5 w-5" />
              <span>{item.name}</span>
            </Link>
          ))}
        </nav>
      </ScrollArea>
    </div>
  );

  if (isMobile) {
    return (
      <Sheet open={open} onOpenChange={onOpenChange}>
        <SheetContent side="left" className="p-0 w-72">
          {content}
        </SheetContent>
      </Sheet>
    );
  }

  return (
    <div className={cn("w-72 border-r", !open && "hidden")}>
      {content}
    </div>
  );
}