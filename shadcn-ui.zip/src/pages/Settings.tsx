import { useState } from "react";
import { BellRing, ChevronRight, Globe, Key, Lock, Mail, Moon, PanelLeft, Save, Sun, User } from "lucide-react";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Separator } from "@/components/ui/separator";
import { Switch } from "@/components/ui/switch";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { UserSettings } from "@/types";

// Mock user settings
const mockUserSettings: UserSettings = {
  id: "1",
  email: "user@example.com",
  username: "videoCreator",
  notificationsEnabled: true,
  emailNotifications: true,
  pushNotifications: true,
  theme: "light",
  language: "en",
  timezone: "America/Los_Angeles",
  sidebar: true,
};

export default function Settings() {
  const [settings, setSettings] = useState<UserSettings>(mockUserSettings);
  
  const handleToggleNotifications = () => {
    setSettings(prev => ({
      ...prev,
      notificationsEnabled: !prev.notificationsEnabled,
    }));
  };
  
  const handleToggleEmailNotifications = () => {
    setSettings(prev => ({
      ...prev,
      emailNotifications: !prev.emailNotifications,
    }));
  };
  
  const handleTogglePushNotifications = () => {
    setSettings(prev => ({
      ...prev,
      pushNotifications: !prev.pushNotifications,
    }));
  };
  
  const handleToggleTheme = () => {
    setSettings(prev => ({
      ...prev,
      theme: prev.theme === "light" ? "dark" : "light",
    }));
  };
  
  const handleToggleSidebar = () => {
    setSettings(prev => ({
      ...prev,
      sidebar: !prev.sidebar,
    }));
  };
  
  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold tracking-tight">Settings</h1>
        <p className="text-muted-foreground">Manage your account preferences.</p>
      </div>
      
      <Tabs defaultValue="general">
        <div className="flex flex-col md:flex-row gap-6">
          <div className="md:w-[200px] flex-shrink-0">
            <TabsList className="flex flex-col h-full w-full rounded-md bg-muted p-1 md:p-2">
              <TabsTrigger value="general" className="justify-start mb-1">
                <User className="mr-2 h-4 w-4" />
                General
              </TabsTrigger>
              <TabsTrigger value="notifications" className="justify-start mb-1">
                <BellRing className="mr-2 h-4 w-4" />
                Notifications
              </TabsTrigger>
              <TabsTrigger value="appearance" className="justify-start mb-1">
                <Sun className="mr-2 h-4 w-4" />
                Appearance
              </TabsTrigger>
              <TabsTrigger value="security" className="justify-start">
                <Lock className="mr-2 h-4 w-4" />
                Security
              </TabsTrigger>
            </TabsList>
          </div>
          <div className="flex-1">
            <TabsContent value="general" className="mt-0">
              <Card>
                <CardHeader>
                  <CardTitle>General Settings</CardTitle>
                  <CardDescription>Manage your basic account information.</CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div className="space-y-2">
                    <Label htmlFor="email">Email Address</Label>
                    <Input
                      id="email"
                      defaultValue={settings.email}
                      type="email"
                    />
                    <p className="text-sm text-muted-foreground">
                      We'll send important notifications to this address.
                    </p>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="username">Username</Label>
                    <Input
                      id="username"
                      defaultValue={settings.username}
                    />
                    <p className="text-sm text-muted-foreground">
                      This will be displayed on your profile.
                    </p>
                  </div>
                  <Separator />
                  <div className="space-y-4">
                    <h3 className="text-lg font-medium">Preferences</h3>
                    <div className="space-y-4">
                      <div className="flex items-center justify-between">
                        <div className="space-y-0.5">
                          <Label htmlFor="language">Language</Label>
                          <p className="text-sm text-muted-foreground">
                            Select your preferred language.
                          </p>
                        </div>
                        <select 
                          className="rounded-md border border-input bg-background px-3 py-2"
                          defaultValue={settings.language}
                        >
                          <option value="en">English</option>
                          <option value="es">Spanish</option>
                          <option value="fr">French</option>
                          <option value="de">German</option>
                          <option value="ja">Japanese</option>
                        </select>
                      </div>
                      <div className="flex items-center justify-between">
                        <div className="space-y-0.5">
                          <Label htmlFor="timezone">Timezone</Label>
                          <p className="text-sm text-muted-foreground">
                            Select your timezone for scheduling.
                          </p>
                        </div>
                        <select 
                          className="rounded-md border border-input bg-background px-3 py-2"
                          defaultValue={settings.timezone}
                        >
                          <option value="America/Los_Angeles">Pacific Time (US)</option>
                          <option value="America/New_York">Eastern Time (US)</option>
                          <option value="Europe/London">London (GMT)</option>
                          <option value="Asia/Tokyo">Tokyo</option>
                          <option value="Australia/Sydney">Sydney</option>
                        </select>
                      </div>
                    </div>
                  </div>
                </CardContent>
                <CardFooter>
                  <Button className="gap-2">
                    <Save className="h-4 w-4" />
                    Save Changes
                  </Button>
                </CardFooter>
              </Card>
            </TabsContent>
            
            <TabsContent value="notifications" className="mt-0">
              <Card>
                <CardHeader>
                  <CardTitle>Notification Settings</CardTitle>
                  <CardDescription>Choose how you want to be notified.</CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div className="flex items-center justify-between">
                    <div className="space-y-0.5">
                      <Label htmlFor="notifications">All Notifications</Label>
                      <p className="text-sm text-muted-foreground">
                        Enable or disable all notifications.
                      </p>
                    </div>
                    <Switch
                      checked={settings.notificationsEnabled}
                      onCheckedChange={handleToggleNotifications}
                    />
                  </div>
                  <Separator />
                  <div className="space-y-4">
                    <h3 className="text-lg font-medium">Notification Types</h3>
                    <div className="space-y-4">
                      <div className="flex items-center justify-between">
                        <div className="space-y-0.5">
                          <Label>Email Notifications</Label>
                          <p className="text-sm text-muted-foreground">
                            Receive email notifications for important updates.
                          </p>
                        </div>
                        <Switch
                          checked={settings.emailNotifications}
                          onCheckedChange={handleToggleEmailNotifications}
                          disabled={!settings.notificationsEnabled}
                        />
                      </div>
                      <div className="flex items-center justify-between">
                        <div className="space-y-0.5">
                          <Label>Push Notifications</Label>
                          <p className="text-sm text-muted-foreground">
                            Receive browser push notifications.
                          </p>
                        </div>
                        <Switch
                          checked={settings.pushNotifications}
                          onCheckedChange={handleTogglePushNotifications}
                          disabled={!settings.notificationsEnabled}
                        />
                      </div>
                    </div>
                  </div>
                  <Separator />
                  <div className="space-y-4">
                    <h3 className="text-lg font-medium">Notification Events</h3>
                    <div className="space-y-4">
                      {[
                        "Post published successfully",
                        "Scheduled post reminder",
                        "Upload failure alerts",
                        "Analytics reports",
                        "Platform connection issues"
                      ].map((event, index) => (
                        <div key={index} className="flex items-center justify-between">
                          <div className="space-y-0.5">
                            <Label>{event}</Label>
                          </div>
                          <Switch
                            defaultChecked={true}
                            disabled={!settings.notificationsEnabled}
                          />
                        </div>
                      ))}
                    </div>
                  </div>
                </CardContent>
                <CardFooter>
                  <Button className="gap-2">
                    <Save className="h-4 w-4" />
                    Save Notification Settings
                  </Button>
                </CardFooter>
              </Card>
            </TabsContent>
            
            <TabsContent value="appearance" className="mt-0">
              <Card>
                <CardHeader>
                  <CardTitle>Appearance Settings</CardTitle>
                  <CardDescription>Customize the look and feel of the application.</CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div className="flex items-center justify-between">
                    <div className="space-y-0.5">
                      <Label>Theme</Label>
                      <p className="text-sm text-muted-foreground">
                        Choose between light and dark theme.
                      </p>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Sun className="h-5 w-5" />
                      <Switch
                        checked={settings.theme === "dark"}
                        onCheckedChange={handleToggleTheme}
                      />
                      <Moon className="h-5 w-5" />
                    </div>
                  </div>
                  <Separator />
                  <div className="flex items-center justify-between">
                    <div className="space-y-0.5">
                      <Label>Sidebar Display</Label>
                      <p className="text-sm text-muted-foreground">
                        Always show sidebar on desktop.
                      </p>
                    </div>
                    <Switch
                      checked={settings.sidebar}
                      onCheckedChange={handleToggleSidebar}
                    />
                  </div>
                  <div className="flex items-center justify-between">
                    <div className="space-y-0.5">
                      <Label>Compact Mode</Label>
                      <p className="text-sm text-muted-foreground">
                        Display more content with reduced spacing.
                      </p>
                    </div>
                    <Switch defaultChecked={false} />
                  </div>
                </CardContent>
                <CardFooter>
                  <Button className="gap-2">
                    <Save className="h-4 w-4" />
                    Save Appearance Settings
                  </Button>
                </CardFooter>
              </Card>
            </TabsContent>
            
            <TabsContent value="security" className="mt-0">
              <Card>
                <CardHeader>
                  <CardTitle>Security Settings</CardTitle>
                  <CardDescription>Manage your account security and passwords.</CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div className="space-y-4">
                    <h3 className="text-lg font-medium">Change Password</h3>
                    <div className="space-y-2">
                      <Label htmlFor="current-password">Current Password</Label>
                      <Input id="current-password" type="password" />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="new-password">New Password</Label>
                      <Input id="new-password" type="password" />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="confirm-password">Confirm New Password</Label>
                      <Input id="confirm-password" type="password" />
                      <p className="text-sm text-muted-foreground">
                        Password must be at least 8 characters and include at least one letter and one number.
                      </p>
                    </div>
                  </div>
                  <Separator />
                  <div className="space-y-4">
                    <h3 className="text-lg font-medium">Two-Factor Authentication</h3>
                    <div className="flex items-center justify-between">
                      <div className="space-y-0.5">
                        <Label>Enable 2FA</Label>
                        <p className="text-sm text-muted-foreground">
                          Add an extra layer of security to your account.
                        </p>
                      </div>
                      <Button variant="outline">Setup 2FA</Button>
                    </div>
                  </div>
                  <Separator />
                  <div className="space-y-4">
                    <h3 className="text-lg font-medium">API Access</h3>
                    <div className="flex items-center justify-between">
                      <div className="space-y-0.5">
                        <Label>API Keys</Label>
                        <p className="text-sm text-muted-foreground">
                          Manage your API keys for external integrations.
                        </p>
                      </div>
                      <Button variant="outline" className="gap-2">
                        <Key className="h-4 w-4" />
                        Manage Keys
                      </Button>
                    </div>
                  </div>
                </CardContent>
                <CardFooter>
                  <Button className="gap-2">
                    <Save className="h-4 w-4" />
                    Update Security Settings
                  </Button>
                </CardFooter>
              </Card>
            </TabsContent>
          </div>
        </div>
      </Tabs>
      
      <Card>
        <CardHeader>
          <CardTitle>Connected Accounts</CardTitle>
          <CardDescription>Manage your social media platform connections.</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          {[
            { name: "TikTok", icon: "/images/SocialMedia.jpg", connected: true, color: "#FF004F" },
            { name: "Instagram", icon: "/images/Instagram.jpg", connected: true, color: "#833AB4" },
            { name: "YouTube", icon: "youtube-icon.svg", connected: true, color: "#FF0000" },
            { name: "Facebook", icon: "/images/Facebook.jpg", connected: false, color: "#1877F2" },
            { name: "Pinterest", icon: "pinterest-icon.svg", connected: false, color: "#E60023" },
          ].map((account, index) => (
            <div key={index} className="flex items-center justify-between p-2">
              <div className="flex items-center gap-3">
                <div 
                  className="h-10 w-10 rounded-full flex items-center justify-center"
                  style={{ backgroundColor: `${account.color}20` }}
                >
                  <div className="h-6 w-6 rounded-full" style={{ backgroundColor: account.color }} />
                </div>
                <div>
                  <h4 className="font-medium">{account.name}</h4>
                  <p className="text-sm text-muted-foreground">
                    {account.connected ? "Connected" : "Not connected"}
                  </p>
                </div>
              </div>
              <Button variant={account.connected ? "outline" : "default"} size="sm">
                {account.connected ? "Disconnect" : "Connect"}
              </Button>
            </div>
          ))}
        </CardContent>
      </Card>
      
      <Card>
        <CardHeader>
          <CardTitle className="text-red-500">Danger Zone</CardTitle>
          <CardDescription>
            Permanently delete your account and all associated data.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <p className="text-sm text-muted-foreground">
            Once you delete your account, there is no going back. Please be certain.
          </p>
        </CardContent>
        <CardFooter>
          <Button variant="destructive">Delete Account</Button>
        </CardFooter>
      </Card>
    </div>
  );
}