import { useNavigate } from "react-router-dom";
import { BarChart3, Calendar, Clock, FileVideo, Share2, TrendingUp } from "lucide-react";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";

// Mock data
const mockStats = [
  { 
    title: "Total Posts", 
    value: "32", 
    change: "+6%", 
    icon: FileVideo,
    description: "From last month",
    trend: "up" 
  },
  { 
    title: "Scheduled", 
    value: "12", 
    change: "+2", 
    icon: Clock,
    description: "Posts upcoming",
    trend: "neutral" 
  },
  { 
    title: "Engagement", 
    value: "24.8%", 
    change: "+2.4%", 
    icon: TrendingUp,
    description: "Average across platforms",
    trend: "up" 
  }
];

const platformStats = [
  { name: "TikTok", posts: 18, color: "#FF004F", progress: 75 },
  { name: "Instagram Reels", posts: 15, color: "#833AB4", progress: 62 },
  { name: "YouTube Shorts", posts: 8, color: "#FF0000", progress: 33 },
];

const recentPosts = [
  { 
    id: "1", 
    title: "Summer Fashion Tips #trending", 
    date: "2025-07-25T14:30:00", 
    platforms: ["TikTok", "Instagram Reels"], 
    status: "published",
    engagement: 1250
  },
  { 
    id: "2", 
    title: "Daily Workout Routine", 
    date: "2025-07-26T09:15:00", 
    platforms: ["YouTube Shorts"], 
    status: "published",
    engagement: 842
  },
  { 
    id: "3", 
    title: "Tech Review - Latest Phone", 
    date: "2025-07-27T11:00:00", 
    platforms: ["TikTok", "YouTube Shorts"], 
    status: "scheduled",
    engagement: 0
  },
];

export default function Dashboard() {
  const navigate = useNavigate();
  
  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Dashboard</h1>
          <p className="text-muted-foreground">Manage your video content across platforms.</p>
        </div>
        <Button onClick={() => navigate("/posts")} className="gap-2">
          <FileVideo className="h-4 w-4" />
          <span>Manage Posts</span>
        </Button>
      </div>
      
      <div className="grid gap-4 md:grid-cols-3">
        {mockStats.map((stat, i) => (
          <Card key={i}>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">
                {stat.title}
              </CardTitle>
              <stat.icon className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{stat.value}</div>
              <p className="text-xs text-muted-foreground">
                <span className={stat.trend === "up" ? "text-green-500" : stat.trend === "down" ? "text-red-500" : ""}>
                  {stat.change}
                </span>
                {" "}{stat.description}
              </p>
            </CardContent>
          </Card>
        ))}
      </div>
      
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-7">
        <Card className="md:col-span-4">
          <CardHeader>
            <CardTitle>Platform Distribution</CardTitle>
            <CardDescription>Your content distribution across video platforms</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {platformStats.map((platform) => (
                <div key={platform.name} className="flex items-center">
                  <div className="w-28 flex-shrink-0">
                    <div className="flex items-center gap-2">
                      <div
                        className="h-3 w-3 rounded-full"
                        style={{ backgroundColor: platform.color }}
                      />
                      <span className="text-sm">{platform.name}</span>
                    </div>
                  </div>
                  <div className="flex-grow px-4">
                    <Progress value={platform.progress} className="h-2" />
                  </div>
                  <div className="flex-shrink-0 w-16 text-right text-sm font-medium">
                    {platform.posts} posts
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
        
        <Card className="md:col-span-3">
          <CardHeader>
            <CardTitle>Upcoming Schedule</CardTitle>
            <CardDescription>Your next scheduled posts</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {recentPosts
                .filter(post => post.status === "scheduled")
                .map((post) => (
                  <div key={post.id} className="flex items-center">
                    <div className="flex-1 space-y-1">
                      <p className="text-sm font-medium leading-none">
                        {post.title}
                      </p>
                      <p className="text-sm text-muted-foreground">
                        {new Date(post.date).toLocaleString('en-US', {
                          month: 'short',
                          day: 'numeric',
                          hour: '2-digit',
                          minute: '2-digit'
                        })}
                      </p>
                    </div>
                    <div className="flex items-center gap-2">
                      {post.platforms.map(platform => (
                        <div 
                          key={platform} 
                          className="h-8 w-8 rounded-full flex items-center justify-center"
                          style={{ 
                            backgroundColor: 
                              platform === "TikTok" ? "#FF004F20" : 
                              platform === "Instagram Reels" ? "#833AB420" : 
                              "#FF000020" 
                          }}
                        >
                          <Share2 
                            className="h-4 w-4"
                            style={{ 
                              color: 
                                platform === "TikTok" ? "#FF004F" : 
                                platform === "Instagram Reels" ? "#833AB4" : 
                                "#FF0000" 
                            }}
                          />
                        </div>
                      ))}
                    </div>
                  </div>
                ))}
            </div>
          </CardContent>
          <CardFooter>
            <Button
              variant="outline"
              size="sm"
              className="w-full gap-2"
              onClick={() => navigate("/calendar")}
            >
              <Calendar className="h-4 w-4" />
              <span>View Calendar</span>
            </Button>
          </CardFooter>
        </Card>
      </div>
      
      <Card>
        <CardHeader>
          <CardTitle>Recent Posts</CardTitle>
          <CardDescription>Your recently published video posts</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {recentPosts
              .filter(post => post.status === "published")
              .map((post) => (
                <div key={post.id} className="flex items-center">
                  <div className="w-12 h-12 rounded bg-muted flex items-center justify-center">
                    <FileVideo className="h-6 w-6 text-foreground/60" />
                  </div>
                  <div className="ml-4 flex-1 space-y-1">
                    <p className="text-sm font-medium leading-none">
                      {post.title}
                    </p>
                    <div className="flex items-center gap-4">
                      <p className="text-sm text-muted-foreground">
                        {new Date(post.date).toLocaleString('en-US', {
                          month: 'short',
                          day: 'numeric'
                        })}
                      </p>
                      <div className="flex items-center gap-1 text-sm text-muted-foreground">
                        <BarChart3 className="h-4 w-4" />
                        <span>{post.engagement.toLocaleString()} engagements</span>
                      </div>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    {post.platforms.map(platform => (
                      <div 
                        key={platform} 
                        className="h-8 w-8 rounded-full flex items-center justify-center"
                        style={{ 
                          backgroundColor: 
                            platform === "TikTok" ? "#FF004F20" : 
                            platform === "Instagram Reels" ? "#833AB420" : 
                            "#FF000020" 
                        }}
                      >
                        <Share2 
                          className="h-4 w-4"
                          style={{ 
                            color: 
                              platform === "TikTok" ? "#FF004F" : 
                              platform === "Instagram Reels" ? "#833AB4" : 
                              "#FF0000" 
                          }}
                        />
                      </div>
                    ))}
                  </div>
                </div>
              ))}
          </div>
        </CardContent>
        <CardFooter>
          <Button
            variant="outline"
            size="sm"
            className="w-full"
            onClick={() => navigate("/posts")}
          >
            View All Posts
          </Button>
        </CardFooter>
      </Card>
    </div>
  );
}