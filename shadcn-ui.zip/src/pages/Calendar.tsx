import { useState } from "react";
import { Calendar as CalendarIcon, ChevronLeft, ChevronRight, Plus } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Calendar as CalendarComponent } from "@/components/ui/calendar";
import { 
  Select, 
  SelectContent, 
  SelectItem, 
  SelectTrigger, 
  SelectValue 
} from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { 
  Dialog, 
  DialogContent, 
  DialogDescription, 
  DialogFooter, 
  DialogHeader, 
  DialogTitle, 
  DialogTrigger 
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { cn } from "@/lib/utils";
import { CalendarEvent } from "@/types";

// Mock data for calendar events
const mockEvents: CalendarEvent[] = [
  {
    id: "1",
    title: "Summer Fashion Tips #trending",
    date: "2025-07-25",
    platforms: ["TikTok", "Instagram Reels"],
    status: "published"
  },
  {
    id: "2",
    title: "Daily Workout Routine",
    date: "2025-07-26",
    platforms: ["YouTube Shorts"],
    status: "published"
  },
  {
    id: "3",
    title: "Tech Review - Latest Phone",
    date: "2025-07-27",
    platforms: ["TikTok", "YouTube Shorts"],
    status: "scheduled"
  },
  {
    id: "4",
    title: "Cooking Tutorial - Quick Dinner",
    date: "2025-07-30",
    platforms: ["TikTok", "Instagram Reels", "YouTube Shorts"],
    status: "draft"
  },
  {
    id: "5",
    title: "Travel Vlog - Beach Day",
    date: "2025-08-02",
    platforms: ["Instagram Reels"],
    status: "scheduled"
  }
];

// Helper function to group events by date
function groupEventsByDate(events: CalendarEvent[]): Record<string, CalendarEvent[]> {
  return events.reduce((acc, event) => {
    if (!acc[event.date]) {
      acc[event.date] = [];
    }
    acc[event.date].push(event);
    return acc;
  }, {} as Record<string, CalendarEvent[]>);
}

export default function CalendarPage() {
  const [date, setDate] = useState<Date>(new Date());
  const [view, setView] = useState<"month" | "week" | "day">("month");
  const [selectedDate, setSelectedDate] = useState<Date | undefined>(new Date());
  
  // Group events by date
  const eventsByDate = groupEventsByDate(mockEvents);
  
  // Get events for selected date
  const selectedDateStr = selectedDate ? 
    selectedDate.toISOString().split('T')[0] : '';
  const eventsForSelectedDate = eventsByDate[selectedDateStr] || [];
  
  const handlePrevious = () => {
    if (view === "month") {
      setDate(new Date(date.getFullYear(), date.getMonth() - 1, 1));
    } else if (view === "week") {
      setDate(new Date(date.getFullYear(), date.getMonth(), date.getDate() - 7));
    } else {
      setDate(new Date(date.getFullYear(), date.getMonth(), date.getDate() - 1));
    }
  };

  const handleNext = () => {
    if (view === "month") {
      setDate(new Date(date.getFullYear(), date.getMonth() + 1, 1));
    } else if (view === "week") {
      setDate(new Date(date.getFullYear(), date.getMonth(), date.getDate() + 7));
    } else {
      setDate(new Date(date.getFullYear(), date.getMonth(), date.getDate() + 1));
    }
  };
  
  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Content Calendar</h1>
          <p className="text-muted-foreground">Schedule and manage your video posts.</p>
        </div>
        <Dialog>
          <DialogTrigger asChild>
            <Button className="gap-2">
              <Plus className="h-4 w-4" />
              <span>Schedule Post</span>
            </Button>
          </DialogTrigger>
          <DialogContent className="sm:max-w-[500px]">
            <DialogHeader>
              <DialogTitle>Schedule New Post</DialogTitle>
              <DialogDescription>
                Create a new video post and schedule it for publishing.
              </DialogDescription>
            </DialogHeader>
            <div className="grid gap-4 py-4">
              <div className="grid grid-cols-4 items-center gap-4">
                <Label htmlFor="post-title" className="text-right">
                  Title
                </Label>
                <Input id="post-title" placeholder="Enter post title" className="col-span-3" />
              </div>
              <div className="grid grid-cols-4 items-center gap-4">
                <Label htmlFor="post-description" className="text-right">
                  Description
                </Label>
                <Textarea id="post-description" placeholder="Enter post description" className="col-span-3" />
              </div>
              <div className="grid grid-cols-4 items-center gap-4">
                <Label htmlFor="scheduled-date" className="text-right">
                  Date
                </Label>
                <div className="col-span-3">
                  <div className="flex items-center gap-2">
                    <Button
                      variant="outline"
                      className="w-full justify-start text-left font-normal"
                      type="button"
                    >
                      <CalendarIcon className="mr-2 h-4 w-4" />
                      <span>Pick a date</span>
                    </Button>
                    <Select>
                      <SelectTrigger className="w-[120px]">
                        <SelectValue placeholder="Time" />
                      </SelectTrigger>
                      <SelectContent>
                        {Array.from({ length: 24 }, (_, i) => {
                          const hour = i < 10 ? `0${i}` : `${i}`;
                          return (
                            <SelectItem key={hour} value={`${hour}:00`}>
                              {`${hour}:00`}
                            </SelectItem>
                          );
                        })}
                      </SelectContent>
                    </Select>
                  </div>
                </div>
              </div>
              <div className="grid grid-cols-4 items-center gap-4">
                <Label className="text-right">
                  Platforms
                </Label>
                <div className="col-span-3 flex flex-wrap gap-2">
                  {["TikTok", "Instagram Reels", "YouTube Shorts"].map((platform) => (
                    <Badge key={platform} variant="outline" className="cursor-pointer hover:bg-accent">
                      {platform}
                    </Badge>
                  ))}
                </div>
              </div>
              <div className="grid grid-cols-4 items-center gap-4">
                <Label htmlFor="video-upload" className="text-right">
                  Video
                </Label>
                <Input id="video-upload" type="file" accept="video/*" className="col-span-3" />
              </div>
            </div>
            <DialogFooter>
              <Button type="submit">Schedule Post</Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>
      
      <Card>
        <CardHeader className="pb-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <Button variant="ghost" size="icon" onClick={handlePrevious}>
                <ChevronLeft className="h-4 w-4" />
              </Button>
              <div className="font-medium">
                {date.toLocaleDateString("en-US", { month: "long", year: "numeric" })}
              </div>
              <Button variant="ghost" size="icon" onClick={handleNext}>
                <ChevronRight className="h-4 w-4" />
              </Button>
            </div>
            <Select value={view} onValueChange={(value: "month" | "week" | "day") => setView(value)}>
              <SelectTrigger className="w-[180px]">
                <SelectValue placeholder="View" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="month">Month View</SelectItem>
                <SelectItem value="week">Week View</SelectItem>
                <SelectItem value="day">Day View</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </CardHeader>
        <CardContent className="p-0">
          <CalendarComponent
            mode="single"
            selected={selectedDate}
            onSelect={setSelectedDate}
            month={date}
            className="p-0"
            modifiers={{
              event: (day) => {
                if (!day) return false;
                const dateStr = day.toISOString().split('T')[0];
                return !!eventsByDate[dateStr];
              },
            }}
            modifiersClassNames={{
              event: "bg-primary/10",
            }}
            components={{
              Day: ({ day, ...props }) => {
                // Check if day is defined before using toISOString()
                const dateStr = day ? day.toISOString().split('T')[0] : '';
                const events = dateStr ? (eventsByDate[dateStr] || []) : [];
                return (
                  <div
                    {...props}
                    className={cn(
                      props.className,
                      "relative h-14 hover:bg-muted/50 p-0"
                    )}
                  >
                    <div className="absolute top-1 right-1">
                      {day ? day.getDate() : ''}
                    </div>
                    {events.length > 0 && (
                      <div className="absolute bottom-1 left-1 right-1">
                        <div className="flex flex-wrap gap-1">
                          {events.slice(0, 2).map((event) => (
                            <div
                              key={event.id}
                              className="w-2 h-2 rounded-full"
                              style={{
                                backgroundColor: 
                                  event.status === "published" 
                                    ? "green" 
                                    : event.status === "scheduled" 
                                    ? "blue" 
                                    : "gray"
                              }}
                            />
                          ))}
                          {events.length > 2 && (
                            <div className="text-xs">+{events.length - 2}</div>
                          )}
                        </div>
                      </div>
                    )}
                  </div>
                );
              }
            }}
          />
        </CardContent>
      </Card>
      
      <Card>
        <CardHeader>
          <CardTitle>
            {selectedDate?.toLocaleDateString("en-US", { 
              weekday: "long", 
              month: "long", 
              day: "numeric", 
              year: "numeric" 
            })}
          </CardTitle>
          <CardDescription>
            {eventsForSelectedDate.length === 0
              ? "No posts scheduled for this date"
              : `${eventsForSelectedDate.length} posts scheduled`}
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          {eventsForSelectedDate.length === 0 ? (
            <div className="flex flex-col items-center justify-center py-10 text-center">
              <CalendarIcon className="h-10 w-10 text-muted-foreground/50" />
              <h3 className="mt-4 text-lg font-medium">No content scheduled</h3>
              <p className="mt-2 text-sm text-muted-foreground">
                Schedule a new video post for this date.
              </p>
              <Dialog>
                <DialogTrigger asChild>
                  <Button className="mt-6 gap-2">
                    <Plus className="h-4 w-4" />
                    <span>Schedule for This Date</span>
                  </Button>
                </DialogTrigger>
                <DialogContent className="sm:max-w-[500px]">
                  <DialogHeader>
                    <DialogTitle>Schedule New Post</DialogTitle>
                    <DialogDescription>
                      Create a new video post and schedule it for publishing.
                    </DialogDescription>
                  </DialogHeader>
                  {/* Dialog content is the same as above */}
                </DialogContent>
              </Dialog>
            </div>
          ) : (
            eventsForSelectedDate.map((event) => (
              <div key={event.id} className="flex items-center justify-between p-4 border rounded-lg">
                <div className="flex-1">
                  <h3 className="text-sm font-medium">{event.title}</h3>
                  <div className="flex items-center space-x-2 mt-1">
                    <Badge
                      variant={
                        event.status === "published"
                          ? "default"
                          : event.status === "scheduled"
                          ? "outline"
                          : "secondary"
                      }
                      className="text-xs"
                    >
                      {event.status.charAt(0).toUpperCase() + event.status.slice(1)}
                    </Badge>
                    <div className="flex items-center space-x-1">
                      {event.platforms.map((platform) => (
                        <Badge 
                          key={platform} 
                          variant="secondary"
                          className="text-xs"
                        >
                          {platform}
                        </Badge>
                      ))}
                    </div>
                  </div>
                </div>
                <Button variant="ghost" size="icon">
                  <ChevronRight className="h-4 w-4" />
                </Button>
              </div>
            ))
          )}
        </CardContent>
      </Card>
    </div>
  );
}