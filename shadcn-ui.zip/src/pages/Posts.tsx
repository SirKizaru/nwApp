import { useState } from "react";
import {
  Clock,
  FileVideo,
  Filter,
  MoreHorizontal,
  Pencil,
  Plus,
  Search,
  Trash2,
} from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogTrigger } from "@/components/ui/dialog";
import { EditPostForm } from "@/components/EditPostForm";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { Post } from "@/types";

// Mock data
const mockPosts: Post[] = [
  {
    id: "1",
    title: "Summer Fashion Tips #trending",
    description: "Quick summer fashion hacks and trends for 2025",
    videoFile: "fashion-tips.mp4",
    thumbnail: "fashion-thumbnail.jpg",
    scheduledDate: "2025-07-25T14:30:00",
    publishedDate: "2025-07-25T14:30:00",
    status: "published",
    platforms: ["TikTok", "Instagram Reels"],
    tags: ["fashion", "summer", "trending"],
  },
  {
    id: "2",
    title: "Daily Workout Routine",
    description: "10-minute full body workout you can do at home",
    videoFile: "workout.mp4",
    thumbnail: "workout-thumbnail.jpg",
    scheduledDate: "2025-07-26T09:15:00",
    publishedDate: "2025-07-26T09:15:00",
    status: "published",
    platforms: ["YouTube Shorts"],
    tags: ["fitness", "workout", "health"],
  },
  {
    id: "3",
    title: "Tech Review - Latest Phone",
    description: "Hands-on review of the newest smartphone on the market",
    videoFile: "tech-review.mp4",
    thumbnail: "/images/smartphone.jpg",
    scheduledDate: "2025-07-27T11:00:00",
    publishedDate: null,
    status: "scheduled",
    platforms: ["TikTok", "YouTube Shorts"],
    tags: ["tech", "review", "smartphone"],
  },
  {
    id: "4",
    title: "Cooking Tutorial - Quick Dinner",
    description: "How to prepare a delicious dinner in under 15 minutes",
    videoFile: "cooking.mp4",
    thumbnail: "cooking-thumbnail.jpg",
    scheduledDate: "2025-07-30T18:00:00",
    publishedDate: null,
    status: "draft",
    platforms: ["TikTok", "Instagram Reels", "YouTube Shorts"],
    tags: ["cooking", "food", "recipe"],
  },
  {
    id: "5",
    title: "Travel Vlog - Beach Day",
    description: "Join me for a day at the most beautiful beach",
    videoFile: "beach-vlog.mp4",
    thumbnail: "beach-thumbnail.jpg",
    scheduledDate: "2025-08-02T12:00:00",
    publishedDate: null,
    status: "scheduled",
    platforms: ["Instagram Reels"],
    tags: ["travel", "beach", "vlog"],
  },
];

export default function Posts() {
  const [posts, setPosts] = useState<Post[]>(mockPosts);
  const [searchTerm, setSearchTerm] = useState("");
  const [statusFilter, setStatusFilter] = useState<string>("all");
  const [platformFilter, setPlatformFilter] = useState<string>("all");
  const [activeTab, setActiveTab] = useState<string>("all");
  const [editingPost, setEditingPost] = useState<Post | undefined>(undefined);
  const [editDialogOpen, setEditDialogOpen] = useState(false);
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
  const [postToDelete, setPostToDelete] = useState<string | null>(null);
  
  // Filter posts based on search, status, and platform
  const filteredPosts = posts.filter((post) => {
    const matchesSearch = post.title.toLowerCase().includes(searchTerm.toLowerCase()) || 
                         post.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         post.tags.some(tag => tag.toLowerCase().includes(searchTerm.toLowerCase()));
    
    const matchesStatus = statusFilter === "all" || post.status === statusFilter;
    
    const matchesPlatform = platformFilter === "all" || 
                          post.platforms.includes(platformFilter);
    
    const matchesTab = activeTab === "all" || 
                     (activeTab === "published" && post.status === "published") ||
                     (activeTab === "scheduled" && post.status === "scheduled") ||
                     (activeTab === "drafts" && post.status === "draft");
                     
    return matchesSearch && matchesStatus && matchesPlatform && matchesTab;
  });
  
  const handleEditPost = (post: Post) => {
    setEditingPost(post);
    setEditDialogOpen(true);
  };
  
  const handleSavePost = (updatedPost: Post) => {
    setPosts(posts.map(post => post.id === updatedPost.id ? updatedPost : post));
    toast.success("Post updated successfully");
  };
  
  const handleDeleteConfirm = (postId: string) => {
    setPostToDelete(postId);
    setDeleteDialogOpen(true);
  };
  
  const handleDeletePost = () => {
    if (postToDelete) {
      setPosts(posts.filter(post => post.id !== postToDelete));
      toast.success("Post deleted successfully");
      setDeleteDialogOpen(false);
      setPostToDelete(null);
    }
  };
  
  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Posts</h1>
          <p className="text-muted-foreground">Manage your video content across platforms.</p>
        </div>
        <Button 
          className="gap-2"
          onClick={() => {
            setEditingPost(undefined);
            setEditDialogOpen(true);
          }}
        >
          <Plus className="h-4 w-4" />
          <span>New Post</span>
        </Button>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-[240px_1fr] gap-6">
        <Card className="md:row-span-2">
          <CardHeader>
            <CardTitle>Filters</CardTitle>
            <CardDescription>Filter your video posts</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Label>Status</Label>
              <Select value={statusFilter} onValueChange={setStatusFilter}>
                <SelectTrigger>
                  <SelectValue placeholder="Select status" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Statuses</SelectItem>
                  <SelectItem value="published">Published</SelectItem>
                  <SelectItem value="scheduled">Scheduled</SelectItem>
                  <SelectItem value="draft">Draft</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label>Platform</Label>
              <Select value={platformFilter} onValueChange={setPlatformFilter}>
                <SelectTrigger>
                  <SelectValue placeholder="Select platform" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Platforms</SelectItem>
                  <SelectItem value="TikTok">TikTok</SelectItem>
                  <SelectItem value="Instagram Reels">Instagram Reels</SelectItem>
                  <SelectItem value="YouTube Shorts">YouTube Shorts</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label>Sort by</Label>
              <Select defaultValue="recent">
                <SelectTrigger>
                  <SelectValue placeholder="Sort posts" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="recent">Most Recent</SelectItem>
                  <SelectItem value="oldest">Oldest First</SelectItem>
                  <SelectItem value="alphabetical">Alphabetical</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <Button variant="outline" className="w-full gap-2">
              <Filter className="h-4 w-4" />
              <span>Reset Filters</span>
            </Button>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="flex-row items-center justify-between space-y-0 pb-2">
            <div className="flex-1">
              <CardTitle>All Posts</CardTitle>
              <CardDescription>
                {filteredPosts.length} {filteredPosts.length === 1 ? 'post' : 'posts'} found
              </CardDescription>
            </div>
            <div className="relative max-w-xs flex-1">
              <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Search posts..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-8"
              />
            </div>
          </CardHeader>
          <CardContent className="p-0">
            <Tabs defaultValue="all" value={activeTab} onValueChange={setActiveTab}>
              <div className="border-b px-4">
                <TabsList className="w-full justify-start rounded-none border-b-0 p-0">
                  <TabsTrigger value="all" className="relative rounded-none border-b-2 border-b-transparent data-[state=active]:border-b-primary data-[state=active]:bg-transparent data-[state=active]:shadow-none">
                    All
                  </TabsTrigger>
                  <TabsTrigger value="published" className="relative rounded-none border-b-2 border-b-transparent data-[state=active]:border-b-primary data-[state=active]:bg-transparent data-[state=active]:shadow-none">
                    Published
                  </TabsTrigger>
                  <TabsTrigger value="scheduled" className="relative rounded-none border-b-2 border-b-transparent data-[state=active]:border-b-primary data-[state=active]:bg-transparent data-[state=active]:shadow-none">
                    Scheduled
                  </TabsTrigger>
                  <TabsTrigger value="drafts" className="relative rounded-none border-b-2 border-b-transparent data-[state=active]:border-b-primary data-[state=active]:bg-transparent data-[state=active]:shadow-none">
                    Drafts
                  </TabsTrigger>
                </TabsList>
              </div>
              <TabsContent value="all" className="m-0">
                <div className="divide-y">
                  {filteredPosts.length > 0 ? (
                    filteredPosts.map((post) => (
                      <div key={post.id} className="flex items-center p-4">
                        <div className="h-14 w-14 rounded-md bg-muted flex items-center justify-center overflow-hidden flex-shrink-0">
                          {post.thumbnail ? (
                            <div 
                              className="h-full w-full bg-cover bg-center"
                              style={{ backgroundImage: `url(${post.thumbnail})` }} 
                            />
                          ) : (
                            <FileVideo className="h-6 w-6 text-foreground/60" />
                          )}
                        </div>
                        <div className="ml-4 flex-1 space-y-1">
                          <div className="flex items-center justify-between">
                            <h3 className="font-medium">{post.title}</h3>
                            <DropdownMenu>
                              <DropdownMenuTrigger asChild>
                                <Button variant="ghost" size="icon">
                                  <MoreHorizontal className="h-4 w-4" />
                                  <span className="sr-only">Actions</span>
                                </Button>
                              </DropdownMenuTrigger>
                              <DropdownMenuContent align="end">
                                <DropdownMenuItem className="flex items-center gap-2 cursor-pointer" onClick={() => handleEditPost(post)}>
                                  <Pencil className="h-4 w-4" /> Edit Post
                                </DropdownMenuItem>
                                <DropdownMenuItem className="flex items-center gap-2 cursor-pointer">
                                  <Clock className="h-4 w-4" /> Reschedule
                                </DropdownMenuItem>
                                <DropdownMenuSeparator />
                                <DropdownMenuItem 
                                  className="flex items-center gap-2 cursor-pointer text-red-500"
                                  onClick={() => handleDeleteConfirm(post.id)}
                                >
                                  <Trash2 className="h-4 w-4" /> Delete
                                </DropdownMenuItem>
                              </DropdownMenuContent>
                            </DropdownMenu>
                          </div>
                          <p className="text-sm text-muted-foreground line-clamp-1">
                            {post.description}
                          </p>
                          <div className="flex items-center gap-3">
                            <div className="flex items-center gap-1">
                              <Badge
                                variant={
                                  post.status === "published"
                                    ? "default"
                                    : post.status === "scheduled"
                                    ? "outline"
                                    : "secondary"
                                }
                                className="text-xs"
                              >
                                {post.status.charAt(0).toUpperCase() + post.status.slice(1)}
                              </Badge>
                            </div>
                            <div className="flex items-center gap-1 text-xs text-muted-foreground">
                              {post.publishedDate ? (
                                <span>
                                  Published: {new Date(post.publishedDate).toLocaleString('en-US', {
                                    month: 'short',
                                    day: 'numeric',
                                    hour: '2-digit',
                                    minute: '2-digit'
                                  })}
                                </span>
                              ) : (
                                <span>
                                  Scheduled: {new Date(post.scheduledDate).toLocaleString('en-US', {
                                    month: 'short',
                                    day: 'numeric',
                                    hour: '2-digit',
                                    minute: '2-digit'
                                  })}
                                </span>
                              )}
                            </div>
                          </div>
                          <div className="flex flex-wrap gap-1 mt-2">
                            {post.platforms.map((platform) => (
                              <Badge 
                                key={platform} 
                                variant="secondary"
                                className="text-xs"
                              >
                                {platform}
                              </Badge>
                            ))}
                          </div>
                        </div>
                      </div>
                    ))
                  ) : (
                    <div className="flex flex-col items-center justify-center py-12 text-center">
                      <FileVideo className="h-12 w-12 text-muted-foreground/50" />
                      <h3 className="mt-4 text-lg font-medium">No posts found</h3>
                      <p className="mt-2 text-sm text-muted-foreground">
                        Try adjusting your filters or search term
                      </p>
                    </div>
                  )}
                </div>
              </TabsContent>
              <TabsContent value="published" className="m-0">
                {/* Same structure as "all" tab but filtered for published posts */}
              </TabsContent>
              <TabsContent value="scheduled" className="m-0">
                {/* Same structure as "all" tab but filtered for scheduled posts */}
              </TabsContent>
              <TabsContent value="drafts" className="m-0">
                {/* Same structure as "all" tab but filtered for draft posts */}
              </TabsContent>
            </Tabs>
          </CardContent>
        </Card>
      </div>
      
      {/* Edit Post Dialog */}
      {editDialogOpen && (
        <EditPostForm
          isOpen={editDialogOpen}
          onClose={() => setEditDialogOpen(false)}
          post={editingPost}
          onSave={handleSavePost}
        />
      )}
      
      {/* Delete confirmation dialog */}
      <AlertDialog open={deleteDialogOpen} onOpenChange={setDeleteDialogOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Are you sure?</AlertDialogTitle>
            <AlertDialogDescription>
              This action cannot be undone. This will permanently delete the
              selected post and remove it from our servers.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={handleDeletePost} className="bg-destructive">
              Delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}