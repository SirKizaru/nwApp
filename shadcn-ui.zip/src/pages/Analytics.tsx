import { useState } from "react";
import {
  BarChart,
  Calendar,
  ChevronDown,
  Download,
  LineChart,
  RefreshCw,
  Share2
} from "lucide-react";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Analytics as AnalyticsType, Post } from "@/types";

// Mock data for analytics
const mockAnalytics: AnalyticsType[] = [
  { postId: "1", platformId: "1", views: 12500, likes: 2300, comments: 180, shares: 320, date: "2025-07-25" },
  { postId: "1", platformId: "2", views: 9800, likes: 1700, comments: 140, shares: 250, date: "2025-07-25" },
  { postId: "2", platformId: "3", views: 8400, likes: 1200, comments: 95, shares: 180, date: "2025-07-26" },
];

const mockPosts: Post[] = [
  {
    id: "1",
    title: "Summer Fashion Tips #trending",
    description: "Quick summer fashion hacks and trends for 2025",
    videoFile: "fashion-tips.mp4",
    thumbnail: "fashion-thumbnail.jpg",
    scheduledDate: "2025-07-25T14:30:00",
    publishedDate: "2025-07-25T14:30:00",
    status: "published",
    platforms: ["TikTok", "Instagram Reels"],
    tags: ["fashion", "summer", "trending"],
  },
  {
    id: "2",
    title: "Daily Workout Routine",
    description: "10-minute full body workout you can do at home",
    videoFile: "workout.mp4",
    thumbnail: "workout-thumbnail.jpg",
    scheduledDate: "2025-07-26T09:15:00",
    publishedDate: "2025-07-26T09:15:00",
    status: "published",
    platforms: ["YouTube Shorts"],
    tags: ["fitness", "workout", "health"],
  },
];

// Helper function to calculate total metrics across all platforms
const calculateTotals = () => {
  return mockAnalytics.reduce(
    (acc, curr) => {
      acc.views += curr.views;
      acc.likes += curr.likes;
      acc.comments += curr.comments;
      acc.shares += curr.shares;
      return acc;
    },
    { views: 0, likes: 0, comments: 0, shares: 0 }
  );
};

// Engagement rate calculation (likes + comments + shares) / views * 100
const calculateEngagementRate = () => {
  const totals = calculateTotals();
  return ((totals.likes + totals.comments + totals.shares) / totals.views * 100).toFixed(2);
};

// Platform performance calculation
const calculatePlatformPerformance = () => {
  const platforms = [
    { id: "1", name: "TikTok", color: "#FF004F" },
    { id: "2", name: "Instagram Reels", color: "#833AB4" },
    { id: "3", name: "YouTube Shorts", color: "#FF0000" },
  ];
  
  return platforms.map(platform => {
    const platformAnalytics = mockAnalytics.filter(a => a.platformId === platform.id);
    const totalViews = platformAnalytics.reduce((sum, a) => sum + a.views, 0);
    const totalEngagements = platformAnalytics.reduce(
      (sum, a) => sum + a.likes + a.comments + a.shares, 0
    );
    
    return {
      ...platform,
      views: totalViews,
      engagements: totalEngagements,
      engagementRate: totalViews ? (totalEngagements / totalViews * 100).toFixed(2) : "0.00"
    };
  });
};

// Mock data for charts
const generateChartData = () => {
  const dates = Array.from({ length: 30 }, (_, i) => {
    const date = new Date();
    date.setDate(date.getDate() - 29 + i);
    return date.toISOString().split('T')[0];
  });
  
  return {
    dates,
    views: dates.map(() => Math.floor(Math.random() * 1000) + 200),
    engagements: dates.map(() => Math.floor(Math.random() * 500) + 100),
  };
};

export default function Analytics() {
  const [timeframe, setTimeframe] = useState<string>("30d");
  const [chartType, setChartType] = useState<"engagement" | "views">("views");
  
  const totals = calculateTotals();
  const engagementRate = calculateEngagementRate();
  const platformPerformance = calculatePlatformPerformance();
  const chartData = generateChartData();
  
  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Analytics</h1>
          <p className="text-muted-foreground">Track the performance of your video content.</p>
        </div>
        <div className="flex flex-col sm:flex-row gap-2">
          <Select value={timeframe} onValueChange={setTimeframe}>
            <SelectTrigger className="w-[180px]">
              <Calendar className="mr-2 h-4 w-4" />
              <SelectValue placeholder="Select timeframe" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="7d">Last 7 days</SelectItem>
              <SelectItem value="30d">Last 30 days</SelectItem>
              <SelectItem value="90d">Last 90 days</SelectItem>
              <SelectItem value="year">This year</SelectItem>
            </SelectContent>
          </Select>
          <Button variant="outline" size="icon">
            <RefreshCw className="h-4 w-4" />
          </Button>
          <Button variant="outline" className="gap-2">
            <Download className="h-4 w-4" />
            <span className="hidden sm:inline">Export</span>
          </Button>
        </div>
      </div>
      
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Views</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{totals.views.toLocaleString()}</div>
            <div className="text-xs text-muted-foreground">
              <span className="text-green-500">+12.5%</span> from last {timeframe === "7d" ? "week" : timeframe === "30d" ? "month" : "period"}
            </div>
            <div className="mt-4 h-1 w-full rounded-full bg-muted overflow-hidden">
              <div className="h-full bg-primary" style={{ width: "70%" }}></div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Likes</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{totals.likes.toLocaleString()}</div>
            <div className="text-xs text-muted-foreground">
              <span className="text-green-500">+8.2%</span> from last {timeframe === "7d" ? "week" : timeframe === "30d" ? "month" : "period"}
            </div>
            <div className="mt-4 h-1 w-full rounded-full bg-muted overflow-hidden">
              <div className="h-full bg-primary" style={{ width: "65%" }}></div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Comments</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{totals.comments.toLocaleString()}</div>
            <div className="text-xs text-muted-foreground">
              <span className="text-green-500">+15.3%</span> from last {timeframe === "7d" ? "week" : timeframe === "30d" ? "month" : "period"}
            </div>
            <div className="mt-4 h-1 w-full rounded-full bg-muted overflow-hidden">
              <div className="h-full bg-primary" style={{ width: "82%" }}></div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Engagement Rate</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{engagementRate}%</div>
            <div className="text-xs text-muted-foreground">
              <span className="text-green-500">+3.8%</span> from last {timeframe === "7d" ? "week" : timeframe === "30d" ? "month" : "period"}
            </div>
            <div className="mt-4 h-1 w-full rounded-full bg-muted overflow-hidden">
              <div className="h-full bg-primary" style={{ width: `${Math.min(parseFloat(engagementRate) * 3, 100)}%` }}></div>
            </div>
          </CardContent>
        </Card>
      </div>
      
      <div className="grid gap-6 md:grid-cols-7">
        <Card className="md:col-span-4">
          <CardHeader>
            <div className="flex justify-between">
              <div>
                <CardTitle>Performance Over Time</CardTitle>
                <CardDescription>
                  Trends for the last {timeframe === "7d" ? "7 days" : timeframe === "30d" ? "30 days" : "90 days"}
                </CardDescription>
              </div>
              <Tabs value={chartType} onValueChange={(value) => setChartType(value as "engagement" | "views")}>
                <TabsList className="grid w-full grid-cols-2">
                  <TabsTrigger value="views" className="text-xs">Views</TabsTrigger>
                  <TabsTrigger value="engagement" className="text-xs">Engagement</TabsTrigger>
                </TabsList>
              </Tabs>
            </div>
          </CardHeader>
          <CardContent className="pl-0">
            <div>
              {chartType === "views" ? (
                <div className="h-[300px] w-full">
                  {/* This is a mock chart visualization - in a real app you'd use a charting library */}
                  <div className="flex h-full items-end gap-[2px]">
                    {chartData.views.map((value, i) => (
                      <div 
                        key={i} 
                        className="bg-primary/90 rounded-t w-full"
                        style={{ height: `${(value / Math.max(...chartData.views) * 100)}%` }}
                      ></div>
                    ))}
                  </div>
                  <div className="mt-2 text-xs text-muted-foreground text-center">
                    {chartData.dates[0]} — {chartData.dates[chartData.dates.length - 1]}
                  </div>
                </div>
              ) : (
                <div className="h-[300px] w-full">
                  <div className="flex h-full items-end gap-[2px]">
                    {chartData.engagements.map((value, i) => (
                      <div 
                        key={i} 
                        className="bg-primary/90 rounded-t w-full"
                        style={{ height: `${(value / Math.max(...chartData.engagements) * 100)}%` }}
                      ></div>
                    ))}
                  </div>
                  <div className="mt-2 text-xs text-muted-foreground text-center">
                    {chartData.dates[0]} — {chartData.dates[chartData.dates.length - 1]}
                  </div>
                </div>
              )}
            </div>
          </CardContent>
        </Card>
        <Card className="md:col-span-3">
          <CardHeader>
            <CardTitle>Platform Breakdown</CardTitle>
            <CardDescription>
              Performance comparison by platform
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-8">
            {platformPerformance.map(platform => (
              <div key={platform.id} className="space-y-2">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <div 
                      className="h-4 w-4 rounded-full" 
                      style={{ backgroundColor: platform.color }}
                    ></div>
                    <span className="text-sm font-medium">{platform.name}</span>
                  </div>
                  <span className="text-sm font-medium">{platform.engagementRate}%</span>
                </div>
                <div className="h-2 w-full rounded-full bg-muted overflow-hidden">
                  <div 
                    className="h-full rounded-full" 
                    style={{ 
                      width: `${Math.min(parseFloat(platform.engagementRate) * 3, 100)}%`,
                      backgroundColor: platform.color 
                    }}
                  ></div>
                </div>
                <div className="flex justify-between text-xs text-muted-foreground">
                  <span>{platform.views.toLocaleString()} views</span>
                  <span>{platform.engagements.toLocaleString()} engagements</span>
                </div>
              </div>
            ))}
          </CardContent>
        </Card>
      </div>
      
      <Card>
        <CardHeader>
          <CardTitle>Top Performing Posts</CardTitle>
          <CardDescription>
            Your best-performing video content for the selected period
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-6">
            {mockPosts.map(post => {
              // Find all analytics for this post across platforms
              const postAnalytics = mockAnalytics.filter(a => a.postId === post.id);
              const totalViews = postAnalytics.reduce((sum, a) => sum + a.views, 0);
              const totalLikes = postAnalytics.reduce((sum, a) => sum + a.likes, 0);
              const totalComments = postAnalytics.reduce((sum, a) => sum + a.comments, 0);
              const totalShares = postAnalytics.reduce((sum, a) => sum + a.shares, 0);
              
              return (
                <div key={post.id} className="flex gap-4 p-4 border rounded-lg">
                  <div className="h-24 w-24 rounded bg-muted flex-shrink-0"></div>
                  <div className="flex-1 space-y-2">
                    <h3 className="font-medium">{post.title}</h3>
                    <p className="text-sm text-muted-foreground">{post.description}</p>
                    <div className="flex flex-wrap items-center gap-x-6 gap-y-2 text-sm">
                      <span className="flex items-center gap-1">
                        <LineChart className="h-4 w-4" />
                        {totalViews.toLocaleString()} views
                      </span>
                      <span className="flex items-center gap-1">
                        <BarChart className="h-4 w-4" />
                        {totalLikes.toLocaleString()} likes
                      </span>
                      <span>
                        {totalComments.toLocaleString()} comments
                      </span>
                      <span>
                        {totalShares.toLocaleString()} shares
                      </span>
                    </div>
                  </div>
                  <div className="flex items-start gap-2">
                    {post.platforms.map(platform => (
                      <div 
                        key={platform} 
                        className="h-8 w-8 rounded-full flex items-center justify-center"
                        style={{ 
                          backgroundColor: 
                            platform === "TikTok" ? "#FF004F20" : 
                            platform === "Instagram Reels" ? "#833AB420" : 
                            "#FF000020" 
                        }}
                      >
                        <Share2 
                          className="h-4 w-4"
                          style={{ 
                            color: 
                              platform === "TikTok" ? "#FF004F" : 
                              platform === "Instagram Reels" ? "#833AB4" : 
                              "#FF0000" 
                          }}
                        />
                      </div>
                    ))}
                    <Button variant="ghost" size="icon">
                      <ChevronDown className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              );
            })}
          </div>
        </CardContent>
        <CardFooter>
          <Button variant="outline" className="w-full">View All Analytics</Button>
        </CardFooter>
      </Card>
    </div>
  );
}