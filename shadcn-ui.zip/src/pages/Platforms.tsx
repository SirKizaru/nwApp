import { useState } from "react";
import { Check, Link, Plus, Settings } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Switch } from "@/components/ui/switch";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Platform } from "@/types";

// Mock platform data
const mockPlatforms: Platform[] = [
  {
    id: "1",
    name: "TikTok",
    icon: "tiktok-icon.svg",
    active: true,
    color: "#FF004F"
  },
  {
    id: "2",
    name: "Instagram Reels",
    icon: "/images/Instagram.jpg",
    active: true,
    color: "#833AB4"
  },
  {
    id: "3",
    name: "YouTube Shorts",
    icon: "youtube-icon.svg",
    active: true,
    color: "#FF0000"
  }
];

export default function Platforms() {
  const [platforms, setPlatforms] = useState<Platform[]>(mockPlatforms);
  
  const togglePlatform = (id: string) => {
    setPlatforms((prev) =>
      prev.map((platform) =>
        platform.id === id ? { ...platform, active: !platform.active } : platform
      )
    );
  };
  
  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Platforms</h1>
          <p className="text-muted-foreground">Connect and manage your video content platforms.</p>
        </div>
        <Dialog>
          <DialogTrigger asChild>
            <Button className="gap-2">
              <Plus className="h-4 w-4" />
              <span>Add Platform</span>
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Connect New Platform</DialogTitle>
              <DialogDescription>
                Add a new platform to schedule and publish your video content.
              </DialogDescription>
            </DialogHeader>
            <div className="grid gap-4 py-4">
              <div className="grid grid-cols-4 items-center gap-4">
                <Label htmlFor="platform-name" className="text-right">
                  Platform
                </Label>
                <div className="col-span-3">
                  <select className="w-full rounded-md border border-input bg-background px-3 py-2">
                    <option value="">Select a platform</option>
                    <option value="tiktok">TikTok</option>
                    <option value="instagram">Instagram Reels</option>
                    <option value="youtube">YouTube Shorts</option>
                    <option value="facebook">Facebook Reels</option>
                    <option value="pinterest">Pinterest Idea Pins</option>
                  </select>
                </div>
              </div>
              <div className="grid grid-cols-4 items-center gap-4">
                <Label htmlFor="account-name" className="text-right">
                  Account
                </Label>
                <Input id="account-name" placeholder="Your account username" className="col-span-3" />
              </div>
              <div className="grid grid-cols-4 items-center gap-4">
                <Label htmlFor="api-key" className="text-right">
                  API Key
                </Label>
                <Input id="api-key" type="password" placeholder="Enter your API key" className="col-span-3" />
              </div>
            </div>
            <DialogFooter>
              <Button type="submit">Connect Platform</Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>
      
      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
        {platforms.map((platform) => (
          <Card key={platform.id} className="overflow-hidden">
            <CardHeader style={{ backgroundColor: `${platform.color}20` }} className="pb-2">
              <div className="flex items-center justify-between">
                <CardTitle className="flex items-center gap-2">
                  {/* Simple color circle as platform icon */}
                  <div 
                    className="w-6 h-6 rounded-full" 
                    style={{ backgroundColor: platform.color }} 
                  />
                  {platform.name}
                </CardTitle>
                <Switch
                  checked={platform.active}
                  onCheckedChange={() => togglePlatform(platform.id)}
                />
              </div>
              <CardDescription>
                {platform.active ? "Connected and active" : "Connection disabled"}
              </CardDescription>
            </CardHeader>
            <CardContent className="p-6 space-y-4">
              <div className="space-y-2">
                <div className="text-sm font-medium">Account</div>
                <div className="flex items-center gap-2 text-sm text-muted-foreground">
                  <span>@username_{platform.name.toLowerCase().replace(' ', '_')}</span>
                </div>
              </div>
              <div className="space-y-2">
                <div className="text-sm font-medium">Stats</div>
                <div className="grid grid-cols-2 gap-2">
                  <div className="text-sm">
                    <div>Posts</div>
                    <div className="font-medium">{Math.floor(Math.random() * 20) + 5}</div>
                  </div>
                  <div className="text-sm">
                    <div>Scheduled</div>
                    <div className="font-medium">{Math.floor(Math.random() * 5) + 1}</div>
                  </div>
                </div>
              </div>
            </CardContent>
            <CardFooter className="flex gap-2 border-t p-4 pt-3">
              <Button variant="outline" size="sm" className="gap-2 flex-1">
                <Link className="h-4 w-4" />
                <span>View Account</span>
              </Button>
              <Button variant="outline" size="sm" className="gap-2 flex-1">
                <Settings className="h-4 w-4" />
                <span>Settings</span>
              </Button>
            </CardFooter>
          </Card>
        ))}
        
        <Dialog>
          <DialogTrigger asChild>
            <Card className="flex h-full items-center justify-center border-dashed">
              <CardContent className="flex flex-col items-center justify-center py-12">
                <div className="rounded-full bg-primary/10 p-3">
                  <Plus className="h-6 w-6 text-primary" />
                </div>
                <h3 className="mt-3 font-medium">Add New Platform</h3>
                <p className="mt-1 text-sm text-muted-foreground text-center px-4">
                  Connect a new platform to expand your reach
                </p>
              </CardContent>
            </Card>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Connect New Platform</DialogTitle>
              <DialogDescription>
                Add a new platform to schedule and publish your video content.
              </DialogDescription>
            </DialogHeader>
            {/* Dialog content is the same as above */}
          </DialogContent>
        </Dialog>
      </div>
      
      <Card>
        <CardHeader>
          <CardTitle>Platform Verification</CardTitle>
          <CardDescription>
            Complete verification to enable additional features and higher posting limits.
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="rounded-lg border p-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="h-9 w-9 rounded-full" style={{ backgroundColor: "#FF004F" }}></div>
                <div>
                  <div className="font-medium">TikTok Creator Program</div>
                  <div className="text-sm text-muted-foreground">Verify your creator account to enable auto-posting</div>
                </div>
              </div>
              <div className="flex h-7 w-7 items-center justify-center rounded-full bg-green-100 text-green-600">
                <Check className="h-4 w-4" />
              </div>
            </div>
          </div>
          <div className="rounded-lg border p-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="h-9 w-9 rounded-full" style={{ backgroundColor: "#833AB4" }}></div>
                <div>
                  <div className="font-medium">Instagram Professional Account</div>
                  <div className="text-sm text-muted-foreground">Connect your business account for advanced analytics</div>
                </div>
              </div>
              <Button size="sm" variant="outline">
                Verify
              </Button>
            </div>
          </div>
          <div className="rounded-lg border p-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="h-9 w-9 rounded-full" style={{ backgroundColor: "#FF0000" }}></div>
                <div>
                  <div className="font-medium">YouTube Content ID</div>
                  <div className="text-sm text-muted-foreground">Protect your content with automatic copyright detection</div>
                </div>
              </div>
              <Button size="sm" variant="outline">
                Setup
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}