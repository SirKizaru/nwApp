// Type definitions for the social media post scheduler

export interface Platform {
  id: string;
  name: string;
  icon: string;
  active: boolean;
  color: string;
}

export interface Post {
  id: string;
  title: string;
  description: string;
  videoFile: string;
  thumbnail: string | null;
  scheduledDate: string | null;
  publishedDate: string | null;
  status: "published" | "scheduled" | "draft";
  platforms: string[];
  tags: string[];
}

export interface CalendarEvent {
  id: string;
  title: string;
  date: string;
  platforms: string[];
  status: "published" | "scheduled" | "draft";
}

export interface Analytics {
  postId: string;
  platformId: string;
  views: number;
  likes: number;
  comments: number;
  shares: number;
  date: string;
}

export interface UserSettings {
  id: string;
  email: string;
  username: string;
  notificationsEnabled: boolean;
  emailNotifications: boolean;
  pushNotifications: boolean;
  theme: "light" | "dark";
  language: string;
  timezone: string;
  sidebar: boolean;
}